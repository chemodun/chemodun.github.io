"""Generates the sector layout test extension files and prints the expected layouts."""
import os
import string

ROOT = os.path.dirname(os.path.abspath(__file__))
EXT = 'sector_layout_test'
X_STEP, Z_STEP = 15000000, 8660000

# (test, sectors as (x, z[, y]) km, which sector must come first or None, galaxy (col, row), what it proves)
TESTS = [
    (1, [(0, 0), (50, 0)], 1, (16, 8), 'z tie, S1 first'),
    (2, [(0, 0), (50, 0)], 2, (18, 8), 'z tie, S2 first'),
    (3, [(0, 0), (0, 50)], 1, (20, 8), 'x tie, S1 first'),
    (4, [(0, 0), (0, 50)], 2, (22, 8), 'x tie, S2 first'),
    (5, [(0, 0), (1, -1)], 1, (16, 4), 'no tie, 1 km, S1 first'),
    (6, [(0, 0), (1, -1)], 2, (18, 4), 'no tie, 1 km, S2 first'),
    (7, [(0, 0), (50, 0), (20, 50)], 1, (20, 4), '3 sectors, z tie, S1 first'),
    (8, [(0, 0), (50, 0), (20, 50)], 2, (22, 4), '3 sectors, z tie, S2 first'),
    (9, [(0, 0), (30, 20), (60, 40)], None, (16, 0), '3 sectors, middle x equals the mean'),
    (10, [(0, 0), (60, 40), (90, -20), (150, 10)], None, (18, 0), '4 sectors, upper middle has the higher z, x > z'),
    (11, [(0, 0), (60, -20), (90, 40), (150, 10)], None, (20, 0), '4 sectors, T10 with the middle z swapped'),
    (15, [(-100, 0), (10, 40), (90, -20), (150, 10)], None, (22, 0), '4 sectors, as T10 but x < z'),
    (12, [(0, 0), (40, 30), (80, -30), (120, 20), (160, -10)], None, (16, -4), '5 sectors'),
    (13, [(0, 0, 0), (0, 0, 10)], 1, (18, -4), 'y only, S1 first'),
    (14, [(0, 0, 0), (0, 0, 10)], 2, (20, -4), 'y only, S2 first'),
    (16, [(0, 0), (60, 80), (90, -20), (150, 10)], None, (22, -4), '4 sectors, T10 with S2 z 80: x < z'),
    (17, [(-100, 0), (10, 5), (90, -20), (150, 10)], None, (16, -8), '4 sectors, T15 with S2 z 5: x > z'),
]


def key(name):
    k = 0x811C9DC5
    for b in name.lower().encode('utf-8'):
        if b > 127:
            b -= 256
        k = ((k * 0x01000193) ^ b) & 0xFFFFFFFFFFFFFFFF
    return k


def sector_conn(token, i):
    return f'Cluster_{token}_Sector{i:03d}_connection'


def pick_token(test, first):
    for salt in [''] + list(string.ascii_uppercase):
        token = f'SLT{test:02d}{salt}'
        if first is None:
            return token
        k1, k2 = key(sector_conn(token, 1)), key(sector_conn(token, 2))
        if (k1 < k2) == (first == 1):
            return token
    raise RuntimeError(f'no token for T{test}')


def corner(x, z):
    return ('left' if x < 0 else 'right' if x > 0 else 'centre') + '/' + ('down' if z < 0 else 'up' if z > 0 else 'middle')


def expected(secs, order):
    """secs: {index: (x, z)}, order: indices in child order. Returns {index: text}."""
    if len(order) == 2:
        a, b = order
        sx = 1 if secs[a][0] - secs[b][0] > 0 else -1
        sz = 1 if secs[a][1] - secs[b][1] > 0 else -1
        return {a: corner(sx, sz), b: corner(-sx, -sz)}
    if len(order) == 3:
        s = list(order)
        for i in range(len(s)):
            for j in range(len(s) - 1 - i):
                if secs[s[j + 1]][1] < secs[s[j]][1]:
                    s[j], s[j + 1] = s[j + 1], s[j]
        mean = sum(secs[i][0] for i in order) / 3
        sgn = 1 if secs[s[1]][0] < mean else -1
        return {s[0]: corner(sgn, -1), s[1]: corner(-2 * sgn, 0), s[2]: corner(sgn, 1)}
    if len(order) == 4:
        s = sorted(order, key=lambda i: secs[i][0])
        return {s[0]: 'left/middle', s[3]: 'right/middle', s[1]: 'centre/?', s[2]: 'centre/?'}
    return {i: 'error expected' for i in order}


def main():
    galaxy, clusters, sectors, index, defaults = [], [], [], [], []
    report = []
    for test, offs, first, (col, row), proves in TESTS:
        token = pick_token(test, first)
        cl = f'Cluster_{token}'
        galaxy.append(
            f'    <connection name="{cl}_connection" ref="clusters">\n'
            f'      <offset>\n        <position x="{col * X_STEP}" y="0" z="{row * Z_STEP}" />\n      </offset>\n'
            f'      <macro ref="{cl}_macro" connection="galaxy" />\n    </connection>')
        conns = []
        for i, o in enumerate(offs, 1):
            x, z = o[0] * 1000, o[1] * 1000
            y = o[2] * 1000 if len(o) > 2 else 0
            sm = f'{cl}_Sector{i:03d}_macro'
            pos = '' if (x, y, z) == (0, 0, 0) else (
                f'        <offset>\n          <position x="{x}" y="{y}" z="{z}" />\n        </offset>\n')
            conns.append(
                f'      <connection name="{sector_conn(token, i)}" ref="sectors">\n{pos}'
                f'        <macro ref="{sm}" connection="cluster" />\n      </connection>')
            sectors.append(f'  <macro name="{sm}" class="sector">\n    <component ref="standardsector" />\n  </macro>')
            index.append(f'  <entry name="{sm.lower()}" value="extensions\\{EXT}\\maps\\xu_ep2_universe\\slt_sectors" />')
            defaults.append(
                f'    <dataset macro="{sm}">\n      <properties>\n'
                f'        <identification name="T{test} S{i}" description="T{test} S{i}" />\n'
                f'      </properties>\n    </dataset>')
        clusters.append(
            f'  <macro name="{cl}_macro" class="cluster">\n    <component ref="standardcluster" />\n'
            f'    <connections>\n' + '\n'.join(conns) + '\n    </connections>\n  </macro>')
        index.insert(len(index) - len(offs),
                     f'  <entry name="{cl.lower()}_macro" value="extensions\\{EXT}\\maps\\xu_ep2_universe\\slt_clusters" />')
        defaults.insert(len(defaults) - len(offs),
                        f'    <dataset macro="{cl}_macro">\n      <properties>\n'
                        f'        <identification name="SLT T{test}" description="{proves.replace("<", "&lt;").replace(">", "&gt;")}" />\n'
                        f'      </properties>\n    </dataset>')
        order = sorted(range(1, len(offs) + 1), key=lambda i: key(sector_conn(token, i)))
        secs = {i: (o[0], o[1]) for i, o in enumerate(offs, 1)}
        exp = expected(secs, order)
        report.append(f'T{test:<2} {cl:<20} order {",".join("S%d" % i for i in order):<15} '
                      + '; '.join(f'S{i} {exp[i]}' for i in range(1, len(offs) + 1)))

    def write(rel, text):
        path = os.path.join(ROOT, rel)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8', newline='\n') as f:
            f.write(text)

    head = '<?xml version="1.0" encoding="utf-8"?>\n'
    write('maps/xu_ep2_universe/galaxy.xml', head + '<diff>\n  <add sel="/macros/macro[@name=\'XU_EP2_universe_macro\']/connections">\n'
          + '\n'.join(galaxy) + '\n  </add>\n</diff>\n')
    write('maps/xu_ep2_universe/slt_clusters.xml', head + '<macros>\n' + '\n'.join(clusters) + '\n</macros>\n')
    write('maps/xu_ep2_universe/slt_sectors.xml', head + '<macros>\n' + '\n'.join(sectors) + '\n</macros>\n')
    write('index/macros.xml', head + '<index>\n' + '\n'.join(index) + '\n</index>\n')
    write('libraries/mapdefaults.xml', head + '<diff>\n  <add sel="/defaults">\n' + '\n'.join(defaults) + '\n  </add>\n</diff>\n')
    print('\n'.join(report))


if __name__ == '__main__':
    main()
